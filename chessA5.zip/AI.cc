#include <string>
#include "AI.h"

using namespace std;

// Constructor
AI::AI(string colour) : Player{colour} {}

// Destructor
AI::~AI() {}

